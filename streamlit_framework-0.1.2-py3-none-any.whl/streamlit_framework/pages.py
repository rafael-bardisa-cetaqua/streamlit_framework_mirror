from .src.pages import add_page, add_pages, delete_page, delete_pages
