from .src.state import init_state, get, set, on_state
