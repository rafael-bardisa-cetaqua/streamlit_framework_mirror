from .src.auth import on_auth, login_button, logout_button, register_button
